var cs = [];
cs.push('if (!window.ogcctxfunc8675309) {');
cs.push(' window.ogcctxfunc8675309 = HTMLCanvasElement.prototype.getContext;');
cs.push(' HTMLCanvasElement.prototype.getContext = function (a, b) {');
cs.push('  var la = a.toLowerCase();');
cs.push('  if (la.indexOf("webgl") >= 0) {');
cs.push('   return null;');
cs.push('  };');
cs.push('  if (b) {');
cs.push('   return window.ogcctxfunc8675309.call(this, a, b);');
cs.push('  } else {');
cs.push('   return window.ogcctxfunc8675309.call(this, a);');
cs.push('  };');
cs.push(' };');
cs.push('};');
cs = cs.join('');









var observer = new WebKitMutationObserver(function(mutations) {
 mutations.forEach(function(mutation) {
  for (var i = 0; i < mutation.addedNodes.length; i++) {
   var o = mutation.addedNodes[i];
   if (o.tagName) {
    var tl = (''+o.tagName).toLowerCase();
    if ((tl == 'head') || (tl == 'body')) {
     try {
      var s = document.createElement('script');
      s.text = cs;
      o.appendChild(s);//(s, o.childNodes[0]);
     } catch (e) {
      
     }
     observer.disconnect();
     return;
    };
   };
  };
 });
});
observer.observe(document, { childList: true, subtree: true });