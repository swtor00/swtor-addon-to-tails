var graphCallback = null;

function onGraph(cb) {
  graphCallback = cb;
}

function resetGraph() {}
